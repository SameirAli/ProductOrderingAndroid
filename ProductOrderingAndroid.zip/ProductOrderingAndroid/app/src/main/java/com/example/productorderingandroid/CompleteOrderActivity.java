package com.example.productorderingandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.app.SearchManager;
import android.widget.Toast;

import java.util.ArrayList;

public class CompleteOrderActivity extends AppCompatActivity {

    TextView completeOrderHeading;
    TextView completeOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complete_order);

        completeOrderHeading = findViewById(R.id.complete_order_heading);
        completeOrder = findViewById(R.id.complete_order);

        if(getIntent().hasExtra(ProductOrderingActivity.Products_TAG)){
            ArrayList<Product> productList = (ArrayList<Product>) getIntent().getSerializableExtra(ProductOrderingActivity.Products_TAG);

            completeOrderHeading.setText("COMPLETE ORDER OVERVIEW: \n\n");

            int i = 0;
            //completeOrder.setText(productList);

            while(i >= 0 && i<productList.size()){
                completeOrder.append("Name: "+productList.get(i).getName()+"\n");
                if(productList.get(i).getOption1()!=""){
                    completeOrder.append("Option: "+productList.get(i).getOption1()+"\n");
                }
                if(productList.get(i).getOption2()!=""){
                    completeOrder.append("Option: "+productList.get(i).getOption2()+"\n");
                }
                completeOrder.append("\n");
                i++;


                //System.out.println(completeOrder.getText().toString());
            }

    }

        Button send = findViewById(R.id.send_order);

        send.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view){
                        String sendOrder = completeOrder.getText().toString();
                        onClickSendOrder(sendOrder);
                    }
                });
}

    protected void onClickSendOrder(String sendOrder){
        Intent intent2 = new Intent(Intent.ACTION_SEND);

        intent2.setType("text/plain");
        intent2.setPackage("com.whatsapp");

        intent2.putExtra(Intent.EXTRA_TEXT, sendOrder);

        if (intent2.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, "WhatsApp is not installed", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(intent2);
    }


}
