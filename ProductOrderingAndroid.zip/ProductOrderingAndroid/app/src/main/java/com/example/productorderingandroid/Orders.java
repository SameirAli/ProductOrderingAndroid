package com.example.productorderingandroid;

import java.util.ArrayList;

public class Orders{

    private ArrayList<Product> orders;
    private int size;

    public Orders(ArrayList<Product> orders, int size){
        this.orders = orders;
        this.size = size;
    }

    public int getSize(){
        return size;
    }

    public ArrayList<Product> getProducts(){
        return orders;
    }
}
