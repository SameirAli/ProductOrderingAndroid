package com.example.productorderingandroid;

public class Product{
    private String option1 = "";
    private String option2 = "";
    private boolean status1 = false;
    private boolean status2 = false;

    public String getOption1(){
        return option1;
    }

    public String getOption2(){
        return option2;
    }

    public void setOption1(String opt1){
        this.option1 = opt1;
    }

    public void setOption2(String opt2){
        this.option2 = opt2;
    }

    public void setStatus1 (boolean stat){
        this.status1 = stat;
    }

    public  void setStatus2 (boolean stat){
        this.status2 = stat;
    }
}
