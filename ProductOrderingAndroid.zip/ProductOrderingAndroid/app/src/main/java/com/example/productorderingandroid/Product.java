package com.example.productorderingandroid;

import java.io.Serializable;

public class Product implements Serializable {
    private String name = "";
    private String option1 = "";
    private String option2 = "";
    private boolean status1 = false;
    private boolean status2 = false;

    public Product(String name, String option1, String option2) {
        this.name = name;
        this.option1 = option1;
        this.option2 = option2;
    }

    public String getName(){
        return name;
    }

    public String getOption1(){
        return option1;
    }

    public String getOption2(){
        return option2;
    }
    public void setName(String name){
        this.name = name;
    }

    public void setOption1(String opt1){
        this.option1 = opt1;
    }

    public void setOption2(String opt2){
        this.option2 = opt2;
    }

    public void setStatus1 (boolean stat){
        this.status1 = stat;
    }

    public  void setStatus2 (boolean stat){
        this.status2 = stat;
    }
}

