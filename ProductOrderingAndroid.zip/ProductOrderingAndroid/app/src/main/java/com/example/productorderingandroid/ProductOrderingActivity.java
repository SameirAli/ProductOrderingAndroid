package com.example.productorderingandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.HashSet;

public class ProductOrderingActivity extends AppCompatActivity {

    ArrayList<String> productList;
    ArrayList<String> productList2;
    String currProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_ordering);

        if(savedInstanceState != null){
            productList = new ArrayList<>(savedInstanceState.getStringArrayList("productList"));
            productList2 = new ArrayList<>(savedInstanceState.getStringArrayList("productList2"));
            currProduct = new String(savedInstanceState.getString("currProduct"));
            TextView textView = (TextView) findViewById(R.id.text_cart);
            textView.setText("Cart Contents: \n");
            for(String v: productList){
                currProduct = v;
                textView.append(currProduct);
                currProduct = "";
            }
        }
        else{
            productList = new ArrayList<String>();
            productList2 = new ArrayList<String>();
            currProduct = new String();
        }
    }

    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        ArrayList<String> temp = new ArrayList<String>(productList);
        ArrayList<String> temp2 = new ArrayList<String>(productList2);
        String tempString = new String(currProduct);
        savedInstanceState.putStringArrayList("productList", temp);
        savedInstanceState.putStringArrayList("productList2", temp2);
        savedInstanceState.putString("currProduct", tempString);
    }

    public void onProduct1Button(View view){
        ToggleButton product1 = (ToggleButton)findViewById(R.id.toggle_buttonP1);
        ToggleButton product2 = (ToggleButton)findViewById(R.id.toggle_buttonP2);
        boolean check = product1.isChecked();
        if(check){
            product2.setChecked(false);
        }
    }

    public void onProduct2Button(View view){
        ToggleButton product1 = (ToggleButton)findViewById(R.id.toggle_buttonP1);
        ToggleButton product2 = (ToggleButton)findViewById(R.id.toggle_buttonP2);
        boolean check = product2.isChecked();
        if(check){
            product1.setChecked(false);
        }
    }


//    public void onCheckboxClicked(View view){
//        CheckBox checkbox = ((CheckBox)view);
//        boolean checked = checkbox.isChecked();
//        String item = checkbox.getText().toString();
//
//        if(checked){
//            productList.add(item);
//            currProduct = (currProduct + " " + item);
//            //productList2.add(item);
//        }
//        else{
//            //productList.remove(item);
//        }
//        for(String v:productList){
//            productList2.add(v);
//        }
//        //currProduct = (currProduct + "\n");
//
//    }

    public void onClickAddToCart(View view) {
        ToggleButton product1 = (ToggleButton)findViewById(R.id.toggle_buttonP1);
        ToggleButton product2 = (ToggleButton)findViewById(R.id.toggle_buttonP2);
        Product product = new Product();
        CheckBox opt1;
        CheckBox opt2;
        if(product1.isChecked()){
            opt1 = (CheckBox)findViewById(R.id.checkBox1P1);
            opt2 = (CheckBox)findViewById(R.id.checkBox2P1);
            if(opt1.isChecked()){
                product.setStatus1(true);
                product.setOption1("10 Years and Up");
                System.out.println(product.getOption1());
            }
            if(opt2.isChecked()) {
                product.setStatus2(true);
                product.setOption2("1000 pieces");
                System.out.println(product.getOption2());
            }
        }
        else if(product2.isChecked()){

        }
        else{
            // TODO:Can add a toaster to prompt an error message say "No Products Selected".
        }

    }

}