package com.example.productorderingandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.os.Handler;
import java.util.Locale;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashSet;

public class ProductOrderingActivity extends AppCompatActivity {

//    ArrayList<Orders> ordersList;
//    int orderSize = 0;
    //private boolean running;
    //private boolean wasRunning;

    ArrayList<Product> productList;
    final static public String Products_TAG = "Products";
    int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_ordering);

        if(savedInstanceState != null){
            productList = (ArrayList<Product>) savedInstanceState.get("productList");
            //running = savedInstanceState.getBoolean("running");
            //wasRunning = savedInstanceState.getBoolean("wasRunning");
        }
        else{
            productList = new ArrayList<Product>();
            productList.add(0,null);

        }
    }

    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        ArrayList<Product> temp = new ArrayList<Product>(productList);
        savedInstanceState.putSerializable("productList", temp);
        //savedInstanceState.putBoolean("running",running);
        //savedInstanceState.putBoolean("wasRunning", wasRunning);
    }
    protected void onStart(){
        super.onStart();
    }

    protected void onResume(){
        super.onResume();
    }
    protected void onPause(){
        super.onPause();
    }

    protected void onStop(){
        super.onStop();
    }
    protected void onDestroy(){
        super.onDestroy();
    }

    public void onProduct1Button(View view){
        ToggleButton product1 = (ToggleButton)findViewById(R.id.toggle_buttonP1);
        ToggleButton product2 = (ToggleButton)findViewById(R.id.toggle_buttonP2);
        ToggleButton product3 = (ToggleButton)findViewById(R.id.toggle_buttonP3);
        CheckBox P1opt1 =(CheckBox)findViewById(R.id.checkBox1P1);
        CheckBox P1opt2 = (CheckBox)findViewById(R.id.checkBox2P1);
        CheckBox P2opt1 = (CheckBox)findViewById(R.id.checkBox1P2);
        CheckBox P2opt2 = (CheckBox)findViewById(R.id.checkBox2P2);
        CheckBox P3opt1 = (CheckBox)findViewById(R.id.checkbox1P3);
        CheckBox P3opt2 = (CheckBox)findViewById(R.id.checkbox2P3);

        TextView P3text = (TextView)findViewById(R.id.P3Text);
        RadioGroup P3rGroup = (RadioGroup)findViewById(R.id.P3radioGroup);
        RadioButton P3R1 = (RadioButton)findViewById(R.id.radioButton1P3);
        RadioButton P3R2 = (RadioButton)findViewById(R.id.radioButton2P3);


        boolean check = product1.isChecked();
        if(check){
            product2.setChecked(false);
            product3.setChecked(false);
            P1opt1.setVisibility(View.VISIBLE);
            P1opt2.setVisibility(View.VISIBLE);
            P2opt1.setVisibility(View.GONE);
            P2opt2.setVisibility(View.GONE);
            P3opt1.setVisibility(View.GONE);
            P3opt2.setVisibility(View.GONE);
            P2opt2.setChecked(false);
            P2opt1.setChecked(false);
            P3opt1.setChecked(false);
            P3opt2.setChecked(false);

            P3text.setVisibility(View.GONE);
            P3rGroup.setVisibility(View.GONE);
            P3R1.setChecked(false);
            P3R2.setChecked(false);
        }
        else{
            P1opt1.setVisibility(View.GONE);
            P1opt2.setVisibility(View.GONE);
            P1opt1.setChecked(false);
            P1opt2.setChecked(false);
        }
    }

    public void onProduct2Button(View view){
        ToggleButton product1 = (ToggleButton)findViewById(R.id.toggle_buttonP1);
        ToggleButton product2 = (ToggleButton)findViewById(R.id.toggle_buttonP2);
        ToggleButton product3 = (ToggleButton)findViewById(R.id.toggle_buttonP3);
        CheckBox P1opt1 =(CheckBox)findViewById(R.id.checkBox1P1);
        CheckBox P1opt2 = (CheckBox)findViewById(R.id.checkBox2P1);
        CheckBox P2opt1 = (CheckBox)findViewById(R.id.checkBox1P2);
        CheckBox P2opt2 = (CheckBox)findViewById(R.id.checkBox2P2);
        CheckBox P3opt1 = (CheckBox)findViewById(R.id.checkbox1P3);
        CheckBox P3opt2 = (CheckBox)findViewById(R.id.checkbox2P3);

        TextView P3text = (TextView)findViewById(R.id.P3Text);
        RadioGroup P3rGroup = (RadioGroup)findViewById(R.id.P3radioGroup);
        RadioButton P3R1 = (RadioButton)findViewById(R.id.radioButton1P3);
        RadioButton P3R2 = (RadioButton)findViewById(R.id.radioButton2P3);

        boolean check = product2.isChecked();
        if(check){
            product1.setChecked(false);
            product3.setChecked(false);
            P2opt1.setVisibility(View.VISIBLE);
            P2opt2.setVisibility(View.VISIBLE);
            P1opt1.setVisibility(View.GONE);
            P1opt2.setVisibility(View.GONE);
            P3opt1.setVisibility(View.GONE);
            P3opt2.setVisibility(View.GONE);

            P3text.setVisibility(View.GONE);
            P3rGroup.setVisibility(View.GONE);
            P3R1.setChecked(false);
            P3R2.setChecked(false);
            P1opt2.setChecked(false);
            P1opt1.setChecked(false);
            P3opt1.setChecked(false);
            P3opt2.setChecked(false);
        }
        else{
            P2opt1.setVisibility(View.GONE);
            P2opt2.setVisibility(View.GONE);
            P2opt1.setChecked(false);
            P2opt2.setChecked(false);
        }
    }

    public void onProduct3Button(View view){
        ToggleButton product1 = (ToggleButton)findViewById(R.id.toggle_buttonP1);
        ToggleButton product2 = (ToggleButton)findViewById(R.id.toggle_buttonP2);
        ToggleButton product3 = (ToggleButton)findViewById(R.id.toggle_buttonP3);
        CheckBox P1opt1 =(CheckBox)findViewById(R.id.checkBox1P1);
        CheckBox P1opt2 = (CheckBox)findViewById(R.id.checkBox2P1);
        CheckBox P2opt1 = (CheckBox)findViewById(R.id.checkBox1P2);
        CheckBox P2opt2 = (CheckBox)findViewById(R.id.checkBox2P2);
        CheckBox P3opt1 = (CheckBox)findViewById(R.id.checkbox1P3);
        CheckBox P3opt2 = (CheckBox)findViewById(R.id.checkbox2P3);

        TextView P3text = (TextView)findViewById(R.id.P3Text);
        RadioGroup P3rGroup = (RadioGroup)findViewById(R.id.P3radioGroup);
        RadioButton P3R1 = (RadioButton)findViewById(R.id.radioButton1P3);
        RadioButton P3R2 = (RadioButton)findViewById(R.id.radioButton2P3);

        boolean check = product3.isChecked();
        if(check){
            product2.setChecked(false);
            product1.setChecked(false);
            P3opt1.setVisibility(View.VISIBLE);
            P3opt2.setVisibility(View.VISIBLE);
            P3text.setVisibility(View.VISIBLE);
            P3rGroup.setVisibility(View.VISIBLE);
            P2opt1.setVisibility(View.GONE);
            P2opt2.setVisibility(View.GONE);
            P1opt1.setVisibility(View.GONE);
            P1opt2.setVisibility(View.GONE);

            P2opt2.setChecked(false);
            P2opt1.setChecked(false);
            P1opt1.setChecked(false);
            P1opt2.setChecked(false);
        }
        else{
            P3opt1.setVisibility(View.GONE);
            P3opt2.setVisibility(View.GONE);
            P3text.setVisibility(View.GONE);
            P3rGroup.setVisibility(View.GONE);
            P3R1.setChecked(false);
            P3R2.setChecked(false);

            P3opt1.setChecked(false);
            P3opt2.setChecked(false);
        }
    }

    public void onClickAddToCart(View view) {
        ToggleButton product1 = (ToggleButton)findViewById(R.id.toggle_buttonP1);
        ToggleButton product2 = (ToggleButton)findViewById(R.id.toggle_buttonP2);
        ToggleButton product3 = (ToggleButton)findViewById(R.id.toggle_buttonP3);

        //productList.add(0,null);
        Product product = new Product("Product "+(i+1),"","", "");
        CheckBox opt1;
        CheckBox opt2;
        RadioGroup rGroup;
        int id;
        RadioButton selected;

        if(product1.isChecked()){
            if((i==0)){
                productList.set(0,product);
            }
            else{
                productList.add(i,product);
            }


            productList.get(i).setName("Lego Andromeda Paradox Skytower (Ages 12+)");
            //System.out.println(productList.get(i).getName() + "\n");
            opt1 = (CheckBox)findViewById(R.id.checkBox1P1);
            opt2 = (CheckBox)findViewById(R.id.checkBox2P1);

            if(opt1.isChecked()){
                productList.get(i).setStatus1(true);
                productList.get(i).setOption1("Include Ancient Fossil Room");
                //System.out.println(productList.get(i).getOption1() + "\n");
                //System.out.println(product.getOption1());
            }
            if(opt2.isChecked()) {
                productList.get(i).setStatus2(true);
                productList.get(i).setOption2("Include Portal Serverbase");
                //System.out.println(productList.get(i).getOption2() + "\n");
                //System.out.println(product.getOption2());
            }
            i++;
        }
        else if(product2.isChecked()){
            if((i==0)){
                productList.set(0,product);
            }
            else{
                productList.add(i,product);
            }
            productList.get(i).setName("TYPHOON Water Gun Pro 76000 hxtm");
            //System.out.println(productList.get(i).getName() + "\n");
            opt1 = (CheckBox)findViewById(R.id.checkBox1P2);
            opt2 = (CheckBox)findViewById(R.id.checkBox2P2);

            if(opt1.isChecked()){
                productList.get(i).setStatus1(true);
                productList.get(i).setOption1("MEGATANK");
                //System.out.println(productList.get(i).getOption1() + "\n");
                //System.out.println(product.getOption1());
            }
            if(opt2.isChecked()) {
                productList.get(i).setStatus2(true);
                productList.get(i).setOption2("Triple Barrel");
                //System.out.println(productList.get(i).getOption2() + "\n");
                //System.out.println(product.getOption2());
            }
            i++;
        }
        else if(product3.isChecked()){
            if((i==0)){
                productList.set(0,product);
            }
            else{
                productList.add(i,product);
            }

            productList.get(i).setName("LEGO Marvel Infinity Gauntlet");
            opt1 = (CheckBox)findViewById(R.id.checkbox1P3);
            opt2 = (CheckBox)findViewById(R.id.checkbox2P3);
            rGroup = (RadioGroup)findViewById(R.id.P3radioGroup);
            id = rGroup.getCheckedRadioButtonId();

            if(opt1.isChecked()){
                productList.get(i).setStatus1(true);
                productList.get(i).setOption1("Include Thanos Figure");
        //        System.out.println(productList.get(i).getOption1());
            }
            if(opt2.isChecked()){
                productList.get(i).setStatus2(true);
                productList.get(i).setOption2("Include BattleShip Set");
           //     System.out.println(productList.get(i).getOption2());
            }
            if(id != -1){
                productList.get(i).setStatus3(true);
                if(id == R.id.radioButton1P3){
                    productList.get(i).setOption3("Include Captain America Figure");
                }
                else{
                    productList.get(i).setOption3("Include Iron Man Figure");
                }
            //    System.out.println(productList.get(i).getOption3());
            }

        }
        else{
            (Toast.makeText(this,"No Product Selected",Toast.LENGTH_SHORT)).show();
        }
        //System.out.println(productList.get(i).getName()+"\n");
        //System.out.println(productList);
        //System.out.println("i is: " + i);
    }

    public void onClickCompleteOrder(View view){

        if(productList.get(0) == null){
            (Toast.makeText(this,"Cart is Empty.",Toast.LENGTH_SHORT)).show();
        }
        else{
            Intent intent = new Intent(ProductOrderingActivity.this, CompleteOrderActivity.class);
            intent.putExtra(Products_TAG, productList);
            startActivity(intent);
        }

//
//        Orders order = new Orders(productList,i);
//        ordersList.add(order);
//        orderSize++;
    }


    //protected void onStop()

    /*public void onClickDisplayOrder(View view) {
        TextView display = (TextView) findViewById(R.id.display_orderList);
        ArrayList<Product> orders;
        Product product;
        Orders checkOrder;
        String out = "Previous orders: \n";
        int j = 0;
        int x = 0;
        while (j < orderSize) {
            out += "*Order #"+(j+1)+": \n";
            checkOrder = ordersList.get(j);
            orders = checkOrder.getProducts();
            while(x < checkOrder.getSize()){
                product = orders.get(x);
                out += (x+1)+product.getName() +"\n";
                x++;
            }
            out += "\n\n";
            j++;
        }
    }*/

    public void onRadioClick(View view){
        RadioGroup radioGroup = (RadioGroup)findViewById(R.id.P3radioGroup);
        int id = radioGroup.getCheckedRadioButtonId();
        if(id == -1){

        }
        else{
            RadioButton radioButton = findViewById(id);
        }
    }
}