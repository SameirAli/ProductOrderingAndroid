package com.example.productorderingandroid;

import java.io.Serializable;
import java.util.ArrayList;

public class Orders implements Serializable {

    private String orderTotal;
    //private int size;

    public Orders(String orders){
        this.orderTotal = orders;
        //this.size = size;
    }

    public String getOrderTotal(){
        return orderTotal;
    }

    public void setOrderTotal(String s){
        this.orderTotal = s;
    }

    //public ArrayList<Product> getProducts(){
        //return orders;
    //}
}
