package com.example.productorderingandroid;

import java.io.Serializable;
import java.util.ArrayList;

public class Orders implements Serializable {
    private String orderDetails;
    public Orders(String orderDetails){
        this.orderDetails = orderDetails;

     }
    public String details(){
        return orderDetails;
    }
}
