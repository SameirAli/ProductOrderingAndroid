package com.hfad.productmanagementandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OrderingStocksActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ordering_stocks);
    }
}