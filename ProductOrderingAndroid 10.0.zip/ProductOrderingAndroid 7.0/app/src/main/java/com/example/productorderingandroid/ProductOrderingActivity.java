package com.example.productorderingandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class ProductOrderingActivity extends AppCompatActivity {

    private ArrayList<Product> productList;
    final static public String Products_TAG = "Products";
    private int i = 0;
    private int j;
    private int x;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_ordering);
        System.out.println("On Create");

        if(savedInstanceState != null){
            productList = (ArrayList<Product>) savedInstanceState.get("productList");
        }
        else{
            productList = new ArrayList<>();
            productList.add(0,null);
        }
    }

    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        ArrayList<Product> temp = new ArrayList<>(productList);
        savedInstanceState.putSerializable("productList", temp);
    }
    protected void onStart(){
        super.onStart();
        System.out.println("POA onStart");
    }

    protected void onResume(){

        super.onResume();
        System.out.println("POA onResume");
    }
    protected void onPause(){

        super.onPause();
        System.out.println("POA onPause");
    }

    protected void onStop(){
        super.onStop();
        System.out.println("POA onStop");
    }
    protected void onDestroy(){

        super.onDestroy();
        System.out.println("POA onDestroy");
    }
    protected void onRestart(){

        super.onRestart();
        System.out.println("POA onRestart");
    }

    public void onProduct1Button(View view){
        ToggleButton product1 = findViewById(R.id.toggle_buttonP1);
        ToggleButton product2 = findViewById(R.id.toggle_buttonP2);
        ToggleButton product3 = findViewById(R.id.toggle_buttonP3);
        CheckBox P1opt1 = findViewById(R.id.checkBox1P1);
        CheckBox P1opt2 = findViewById(R.id.checkBox2P1);
        CheckBox P2opt1 = findViewById(R.id.checkBox1P2);
        CheckBox P2opt2 = findViewById(R.id.checkBox2P2);
        CheckBox P3opt1 = findViewById(R.id.checkbox1P3);
        CheckBox P3opt2 = findViewById(R.id.checkbox2P3);

        TextView P3text = findViewById(R.id.P3Text);
        RadioGroup P3rGroup = findViewById(R.id.P3radioGroup);
        RadioButton P3R1 = findViewById(R.id.radioButton1P3);
        RadioButton P3R2 = findViewById(R.id.radioButton2P3);


        boolean check = product1.isChecked();
        if(check){
            product2.setChecked(false);
            product3.setChecked(false);
            P1opt1.setVisibility(View.VISIBLE);
            P1opt2.setVisibility(View.VISIBLE);
            P2opt1.setVisibility(View.GONE);
            P2opt2.setVisibility(View.GONE);
            P3opt1.setVisibility(View.GONE);
            P3opt2.setVisibility(View.GONE);
            P2opt2.setChecked(false);
            P2opt1.setChecked(false);
            P3opt1.setChecked(false);
            P3opt2.setChecked(false);

            P3text.setVisibility(View.GONE);
            P3rGroup.setVisibility(View.GONE);
            P3R1.setChecked(false);
            P3R2.setChecked(false);
        }
        else{
            P1opt1.setVisibility(View.GONE);
            P1opt2.setVisibility(View.GONE);
            P1opt1.setChecked(false);
            P1opt2.setChecked(false);
        }
    }

    public void onProduct2Button(View view){
        ToggleButton product1 = findViewById(R.id.toggle_buttonP1);
        ToggleButton product2 = findViewById(R.id.toggle_buttonP2);
        ToggleButton product3 = findViewById(R.id.toggle_buttonP3);
        CheckBox P1opt1 = findViewById(R.id.checkBox1P1);
        CheckBox P1opt2 = findViewById(R.id.checkBox2P1);
        CheckBox P2opt1 = findViewById(R.id.checkBox1P2);
        CheckBox P2opt2 = findViewById(R.id.checkBox2P2);
        CheckBox P3opt1 = findViewById(R.id.checkbox1P3);
        CheckBox P3opt2 = findViewById(R.id.checkbox2P3);

        TextView P3text = findViewById(R.id.P3Text);
        RadioGroup P3rGroup = findViewById(R.id.P3radioGroup);
        RadioButton P3R1 = findViewById(R.id.radioButton1P3);
        RadioButton P3R2 = findViewById(R.id.radioButton2P3);

        boolean check = product2.isChecked();
        if(check){
            product1.setChecked(false);
            product3.setChecked(false);
            P2opt1.setVisibility(View.VISIBLE);
            P2opt2.setVisibility(View.VISIBLE);
            P1opt1.setVisibility(View.GONE);
            P1opt2.setVisibility(View.GONE);
            P3opt1.setVisibility(View.GONE);
            P3opt2.setVisibility(View.GONE);

            P3text.setVisibility(View.GONE);
            P3rGroup.setVisibility(View.GONE);
            P3R1.setChecked(false);
            P3R2.setChecked(false);
            P1opt2.setChecked(false);
            P1opt1.setChecked(false);
            P3opt1.setChecked(false);
            P3opt2.setChecked(false);
        }
        else{
            P2opt1.setVisibility(View.GONE);
            P2opt2.setVisibility(View.GONE);
            P2opt1.setChecked(false);
            P2opt2.setChecked(false);
        }
    }

    public void onProduct3Button(View view){
        ToggleButton product1 = findViewById(R.id.toggle_buttonP1);
        ToggleButton product2 = findViewById(R.id.toggle_buttonP2);
        ToggleButton product3 = findViewById(R.id.toggle_buttonP3);
        CheckBox P1opt1 = findViewById(R.id.checkBox1P1);
        CheckBox P1opt2 = findViewById(R.id.checkBox2P1);
        CheckBox P2opt1 = findViewById(R.id.checkBox1P2);
        CheckBox P2opt2 = findViewById(R.id.checkBox2P2);
        CheckBox P3opt1 = findViewById(R.id.checkbox1P3);
        CheckBox P3opt2 = findViewById(R.id.checkbox2P3);

        TextView P3text = findViewById(R.id.P3Text);
        RadioGroup P3rGroup = findViewById(R.id.P3radioGroup);
        RadioButton P3R1 = findViewById(R.id.radioButton1P3);
        RadioButton P3R2 = findViewById(R.id.radioButton2P3);

        boolean check = product3.isChecked();
        if(check){
            product2.setChecked(false);
            product1.setChecked(false);
            P3opt1.setVisibility(View.VISIBLE);
            P3opt2.setVisibility(View.VISIBLE);
            P3text.setVisibility(View.VISIBLE);
            P3rGroup.setVisibility(View.VISIBLE);
            P2opt1.setVisibility(View.GONE);
            P2opt2.setVisibility(View.GONE);
            P1opt1.setVisibility(View.GONE);
            P1opt2.setVisibility(View.GONE);

            P2opt2.setChecked(false);
            P2opt1.setChecked(false);
            P1opt1.setChecked(false);
            P1opt2.setChecked(false);
        }
        else{
            P3opt1.setVisibility(View.GONE);
            P3opt2.setVisibility(View.GONE);
            P3text.setVisibility(View.GONE);
            P3rGroup.setVisibility(View.GONE);
            P3R1.setChecked(false);
            P3R2.setChecked(false);

            P3opt1.setChecked(false);
            P3opt2.setChecked(false);
        }
    }

    public void onClickAddToCart(View view) {
        ToggleButton product1 = findViewById(R.id.toggle_buttonP1);
        ToggleButton product2 = findViewById(R.id.toggle_buttonP2);
        ToggleButton product3 = findViewById(R.id.toggle_buttonP3);

        Product product = new Product("Product "+(i+1),"","", "");
        CheckBox opt1;
        CheckBox opt2;
        RadioGroup rGroup;
        int id;
        RadioButton selected;

        if(i == -1){
            productList.clear();
            productList = new ArrayList<>();
        }

        if((i==0)){
            productList.set(0,product);
       }
        else if(productList.size() > i){
            productList.set(i,product);
        }
        else{
            productList.add(i,product);
        }

        if(product1.isChecked()){
            productList.get(i).setName("Lego Andromeda Paradox Skytower (Ages 12+)");
            opt1 = findViewById(R.id.checkBox1P1);
            opt2 = findViewById(R.id.checkBox2P1);

            if(opt1.isChecked()){
                //productList.get(i).setStatus1(true);
                productList.get(i).setOption1("Include Ancient Fossil Room");
            }
            if(opt2.isChecked()) {
                //productList.get(i).setStatus2(true);
                productList.get(i).setOption2("Include Portal Serverbase");
            }
            i++;
        }
        else if(product2.isChecked()){
            productList.get(i).setName("TYPHOON Water Gun Pro 76000 hxtm");
            opt1 = findViewById(R.id.checkBox1P2);
            opt2 = findViewById(R.id.checkBox2P2);

            if(opt1.isChecked()){
                //productList.get(i).setStatus1(true);
                productList.get(i).setOption1("MEGATANK");
            }
            if(opt2.isChecked()) {
                //productList.get(i).setStatus2(true);
                productList.get(i).setOption2("Triple Barrel");
            }
            i++;
        }
        else if(product3.isChecked()){
            productList.get(i).setName("LEGO Marvel Infinity Gauntlet");
            opt1 = findViewById(R.id.checkbox1P3);
            opt2 = findViewById(R.id.checkbox2P3);
            rGroup = findViewById(R.id.P3radioGroup);
            id = rGroup.getCheckedRadioButtonId();

            if(opt1.isChecked()){
                //productList.get(i).setStatus1(true);
                productList.get(i).setOption1("Include Thanos Figure");
            }
            if(opt2.isChecked()){
                //productList.get(i).setStatus2(true);
                productList.get(i).setOption2("Include BattleShip Set");
            }
            if(id != -1){
                //productList.get(i).setStatus3(true);
                if(id == R.id.radioButton1P3){
                    productList.get(i).setOption3("Include Captain America Figure");
                }
                else{
                    productList.get(i).setOption3("Include Iron Man Figure");
                }
            }
            i++;
        }
        else{
            (Toast.makeText(this,"No Product Selected",Toast.LENGTH_SHORT)).show();
        }
        System.out.println("i = "+ i +"\n size = "+ productList.size());
    }

    public void onClickCompleteOrder(View view){

        if(productList.size()>i){
            x = i;
            j = productList.size() - 1;
            while(j >= i){
                productList.set(j,null);
                j--;
            }
        }
        System.out.println(productList);

        if(productList.get(0) == null){
            (Toast.makeText(this,"Cart is Empty.",Toast.LENGTH_SHORT)).show();
        }
        else{
            Intent intent = new Intent(ProductOrderingActivity.this, CompleteOrderActivity.class);
            intent.putExtra(Products_TAG, productList);
            startActivity(intent);
        }
        i = 0;
    }

    public void onDisplayButton(View view){
        Intent intent = new Intent(ProductOrderingActivity.this, DisplayOrderActivity.class);
        startActivity(intent);

    }

}