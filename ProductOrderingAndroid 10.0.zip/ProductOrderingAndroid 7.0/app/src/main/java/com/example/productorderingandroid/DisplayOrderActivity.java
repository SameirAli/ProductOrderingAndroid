package com.example.productorderingandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class DisplayOrderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_order);

        String text = "";
        String filename = "orders.bin";

        TextView display = findViewById(R.id.display_order_text);
        try{
            FileInputStream in = openFileInput(filename);
            int size  = in.available();
            byte [] buffer = new byte[size];
            in.read(buffer);
            text = new String(buffer);
        } catch (FileNotFoundException e){
            e.printStackTrace();
        } catch(IOException e){
            e.printStackTrace();
        }

        if(text == "" || text == null){
            display.setText("No Previous Orders Found.");
        }
        else{
            display.setText(text);
        }
    }
}