package com.hfad.productmanagementandroid;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link OrderingStocksFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OrderingStocksFragment extends Fragment implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public OrderingStocksFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment OrderingStocksFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OrderingStocksFragment newInstance(String param1, String param2) {
        OrderingStocksFragment fragment = new OrderingStocksFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(savedInstanceState == null){
            OutputViewFragment outputView = new OutputViewFragment();
            FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
            transaction.add(R.id.output_view_container, outputView);
            transaction.addToBackStack(null);
            transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            transaction.commit();
        }
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View layout = inflater.inflate(R.layout.fragment_ordering_stocks, container, false);

        SQLiteOpenHelper dbHelper =new ProductDatabaseHelper(inflater.getContext());
        try{
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.query("PRODUCT",new String [] {"NAME","STOCK_ON_HAND","STOCK_IN_TRANSIT","REORDER_QUANTITY","REORDER_AMOUNT"},
                    null,null,null,null,
                    "_id ASC");

            List<String> names = new ArrayList<>();
            cursor.moveToFirst();
            do {
                names.add(cursor.getString(0));
            }while (cursor.moveToNext());

            Spinner spin = layout.findViewById(R.id.product_names);
            ArrayAdapter<String> adapter = new ArrayAdapter(inflater.getContext(), android.R.layout.simple_list_item_1, names);
            spin.setAdapter(adapter);
            spin.setOnItemSelectedListener(this);

            Button order = layout.findViewById(R.id.make_order_button);
            order.setOnClickListener(this);

            //TextView text = layout.findViewById(R.id.product_info);
            //String firstData = "For the selected product:\n";
            //cursor.moveToFirst();
            //firstData += "Stock on Hand = "+cursor.getInt(1)+" \n";
            //firstData += "Stock in Transit = "+cursor.getInt(2)+" \n";
            //firstData += "Reorder Quantity = "+cursor.getInt(3)+" \n";
            //firstData += "Reorder Amount = "+cursor.getInt(4)+" \n";
            //text.setText(firstData);

            db.close();
            cursor.close();
        }catch (SQLException e){
            Toast toast = Toast.makeText(inflater.getContext(),"Database unavailable ", Toast.LENGTH_SHORT);
            toast.show();
        }

        return layout;
    }

    private void onProductClick(int id){
        id++;
        //String productData = "For the selected product:\n";
        //TextView text = getView().findViewById(R.id.product_info);

        SQLiteOpenHelper dbHelper = new ProductDatabaseHelper(getContext());
        try{

            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.query("PRODUCT", new String[]{"STOCK_ON_HAND","STOCK_IN_TRANSIT","REORDER_QUANTITY","REORDER_AMOUNT"}, "_id = ?",
                    new String[] {Integer.toString(id)}, null, null, null);

            cursor.moveToFirst();
            //productData += "Stock on Hand = "+cursor.getInt(0)+" \n";
            //productData += "Stock in Transit = "+cursor.getInt(1)+" \n";
            //productData += "Reorder Quantity = "+cursor.getInt(2)+" \n";
            //productData += "Reorder Amount = "+cursor.getInt(3)+" \n";
            //text.setText(productData);

            db.close();
            cursor.close();
        }catch(SQLException e){
            Toast toast = Toast.makeText(getContext(),"Database unavailable ", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    private void onMakeOrderClick(){
        EditText orderArea = getView().findViewById(R.id.order_area);
        String makeOrder = orderArea.getText().toString();
        if(makeOrder.isEmpty()){
            Toast toast = Toast.makeText(getContext(),"No value entered", Toast.LENGTH_SHORT);
            toast.show();
            return;
        }

        Spinner spin = getView().findViewById(R.id.product_names);
        String selected = spin.getSelectedItem().toString();
        int orderAmount = Integer.parseInt(makeOrder);
        int SIT = 0;
        int id = 0;
        SQLiteOpenHelper dbHelper = new ProductDatabaseHelper(getContext());

        try{
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.query("PRODUCT", new String[]{"STOCK_IN_TRANSIT","_id"}, "NAME = ?",
                    new String[] {selected}, null, null, null);

            cursor.moveToFirst();
            SIT = cursor.getInt(0);
            id = cursor.getInt(1);

            db.close();
            cursor.close();
        }catch(SQLException e){
            Toast toast = Toast.makeText(getContext(),"Database unavailable ", Toast.LENGTH_SHORT);
            toast.show();
        }

        SIT += orderAmount;
        ContentValues newData = new ContentValues();
        newData.put("STOCK_IN_TRANSIT",SIT);

        try{
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            db.update("PRODUCT",newData,"_id = ?", new String [] {Integer.toString(id)});

            db.close();
        }catch (SQLException e){
            Toast toast = Toast.makeText(getContext(),"Database unavailable ", Toast.LENGTH_SHORT);
            toast.show();
        }

        onProductClick(id-1);

        FrameLayout frame = getView().findViewById(R.id.output_view_container);
        frame.removeAllViews();

        OutputViewFragment frag = new OutputViewFragment();
        OutputViewFragment outputView = new OutputViewFragment();
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        transaction.add(R.id.output_view_container, outputView);
        transaction.addToBackStack(null);
        transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        transaction.commit();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        onProductClick(position);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        onMakeOrderClick();
    }
}