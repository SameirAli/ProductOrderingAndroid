package com.example.productorderingandroid;

import java.io.Serializable;
import java.util.ArrayList;

public class Orders implements Serializable {

    private static int  numOrders = 0;
    private String orderDetails;
    private int orderID;

    public Orders(String orderDetails){
        this.orderDetails = orderDetails;
        numOrders++;
        orderID = numOrders;
     }

    public String toString(){
        return "Order#"+orderID;
    }

}
